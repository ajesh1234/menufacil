import { Component, OnInit } from '@angular/core';

export class LocationTrackerProvider {
	

 
  constructor() {
 
  }
 
  startTracking() {
	
  }
 
  stopTracking() {

 
  }


}
